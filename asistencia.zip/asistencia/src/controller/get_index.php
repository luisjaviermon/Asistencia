<?php
    session_start();
    require_once('model/Usuario.php');
    if(isset($_SESSION['username']) && $_SESSION['username']!='' && $_SESSION['expire'] > time()){
        require_once("view/panel.html");
    }else{
        $usuario = new Usuario();
        $users = $usuario->get_usuarios();
        require_once("view/login.html");
    }

?>