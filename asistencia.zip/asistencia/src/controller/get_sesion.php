<?php
        error_reporting(E_ALL);
        ini_set("display_errors", 1);
        session_start();
        require_once("../model/Conexion_BD.php");
        require_once("../model/Usuario.php");
        require_once("../controller/get_real_ip.php");
        require_once("../assets/vendor/Autoload/autoload.php");
        require_once("../assets/vendor/FreeIPA/bootstrap.php");        
    $host = 'cerberus.intranet.ingenieria.unam.mx';
    $certificate = "../assets/vendor/FreeIPA/certs/ipa.demo1.freeipa.org_ca.crt";
    try {
        $ipa = new \FreeIPA\APIAccess\Main($host, $certificate);     
        $usuario = new Usuario();
        if((!isset($_SESSION['loggedin']) || $_SESSION['expire'] < time() || $_SESSION['username'] == '')){
            $username = $_POST['usuario'];
            $password = $_POST['contraseña'];
            $auth = $ipa->connection()->authenticate($username, $password);
            if($username == 'admin' && $password == 'root'){
                $_SESSION['ip'] = getRealIP();
                $_SESSION['username'] = $username;
                $_SESSION['start'] = time();
                $_SESSION['expire'] = $_SESSION['start'] + (15 * 60);
                $_SESSION['id'] = 1;
                $_SESSION['tipo'] = 1;
                $session = array('id'=>$_SESSION['id'], 'usuario'=>$_SESSION['username'], 'tipo' => $_SESSION['tipo']);
                $_SESSION['loggedin'] = true;
                echo json_encode($session);
            }else{
                if ($auth) {
                    $_SESSION['ip'] = getRealIP();
                    $_SESSION['username'] = $username;
                    $_SESSION['start'] = time();
                    $_SESSION['expire'] = $_SESSION['start'] + (15 * 60);
                    $row = $usuario->check_login($username);
                    if($row == false){
                        $r = get_object_vars($ipa->user()->get($username));
                        $nombre = $r['givenname'][0];
                        $apellido = $r['sn'][0];
                        $usuario->set_usuario($username,$nombre,$apellido,'3');
                        $row = $usuario->check_login($username);
                    }
                    $_SESSION['id'] = $row['ID_USUARIO'];
                    $session = array('id'=>$_SESSION['id'], 'usuario'=>$_SESSION['username'], 'tipo' => $row['ID_TIPO']);
                    $_SESSION['tipo'] = $row['ID_TIPO'];
                    $_SESSION['loggedin'] = true;
                    echo json_encode($session);
                }
                else {
                    $_SESSION['username'] = "";
                    $session = array('usuario'=>"",'tipo' => -1);
                    echo json_encode($session);
                }
            }
        }else{
            $session = array('usuario'=>$_SESSION['username'],'tipo' => 200);
            echo json_encode($session);
        }
    } catch (Exception $e) {
        echo("Error {$e->getCode()}: {$e->getMessage()}");
    }
        
    /*error_reporting(E_ALL);
    ini_set("display_errors", 1);
    session_start();
    require_once("../model/Conexion_BD.php");
    require_once("../model/Usuario.php");
    require_once("../controller/get_real_ip.php");
    $usuario = new Usuario();
    if((!isset($_SESSION['loggedin']) || $_SESSION['expire'] < time())){
        $username = $_POST['usuario'];
        $password = $_POST['contraseña'];
        $row = $usuario->check_login($username);
        if($row != false){
            $hash_verificacion = crypt($password,$row['CONTRASEÑA']);
            if ($hash_verificacion == $row['CONTRASEÑA']) { 
                $_SESSION['ip'] = getRealIP();
                $_SESSION['tipo'] = $row['ID_TIPO'];
                $_SESSION['loggedin'] = true;
                $_SESSION['id'] = $row['ID_USUARIO'];
                $_SESSION['username'] = $row['USUARIO'];
                $_SESSION['start'] = time();
                $_SESSION['expire'] = $_SESSION['start'] + (15 * 60);
                $session = array('id'=>$_SESSION['id'], 'usuario'=>$_SESSION['username'], 'tipo' => $row['ID_TIPO']);
                echo json_encode($session);
            } else {
                $_SESSION['username'] = "";
                $session = array('usuario'=>"",'tipo' => -1);
                echo json_encode($session);
            }
        }else {
            $session = array('usuario'=>"",'tipo' => -1);
            echo json_encode($session);
        }
    }else{
        $session = array('usuario'=>$_SESSION['username'],'tipo' => 200);
            echo json_encode($session);
    }*/
