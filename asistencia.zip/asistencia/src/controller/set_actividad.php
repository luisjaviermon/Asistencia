<?php 
    //error_reporting(E_ALL);
    //ini_set("display_errors", 1);
    require_once("check_session.php");
    require_once("../model/Conexion_BD.php");
    require_once("../model/Reporte.php");
    require_once("../model/Usuario.php");
    require_once("../model/Asistencia.php");
    