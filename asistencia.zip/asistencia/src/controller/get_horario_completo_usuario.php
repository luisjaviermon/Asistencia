<?php
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
    session_start();
    require_once("../model/Conexion_BD.php");
    require_once("../model/Horario.php");
    $horario = new Horario();
    $row = $horario->get_horarios_usuario($_GET['id_usuario']);
    $horario = array("id_usuario"=>$_GET['id_usuario'],"horario"=>array());
    foreach ($row as $data) {
        $dataH = array();
        $dataH['id_dia'] = $data['ID_DIA'];
        $dataH['hora_entrada'] = $data['HORA_ENTRADA'];
        $dataH['hora_salida'] = $data['HORA_SALIDA']; 
        $horario['horario'][] = $dataH; 
    }
    
    echo json_encode($horario);
?>