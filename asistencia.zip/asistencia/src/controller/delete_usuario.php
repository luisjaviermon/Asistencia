<?php 
    //error_reporting(E_ALL);
    //ini_set("display_errors", 1);
    require_once("check_session.php");
    require_once("../model/Conexion_BD.php");
    require_once("../model/Usuario.php");
    if($_SESSION['loggedin']== True && $_SESSION['expire'] > time() && $_SESSION['tipo'] == 1){
    $id_usuario = $_POST['id_usuario'];
    $Usuario = new Usuario();
    $res = $Usuario->delete_usuario($id_usuario);
    echo json_encode(array('resultado'=>$res));
    }else{
        http_response_code(401);
        echo json_encode(array('resultado'=>'Accion no autorizada'));
    }
?>