<?php 
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
    date_default_timezone_set('UTC');
    require_once("../model/Conexion_BD.php");
    require_once("../model/Reporte.php");
    require_once("../model/Usuario.php");
    require_once("../model/Asistencia.php");
    $Usuario = new Usuario();
    $Asistencia = new Asistencia();
    $Reporte = new Reporte();
    $_POST = json_decode(file_get_contents("php://input"),true); 
    $usuario = $_POST['usuario'];
    $id_usuario = $Usuario->get_usuario_usuario($usuario)['ID_USUARIO'];
    $date = date('Y-m-d');
    $actividades = $_POST[$date];
    $id_asistencia = $Asistencia->get_asistencia_fecha_usuario($date,$id_usuario)[0]['ID_ASISTENCIA'];
    echo $id_asistencia;
    foreach($actividades as $actividad){
        $programa = $actividad['programa'];
        $tiempo = $actividad['tiempo'];
        $info = $actividad['porcentaje'];
        $Reporte->set_reporte_actividad($id_asistencia,$programa,$tiempo,$info);
    }