<?php 
    //error_reporting(E_ALL);
    //ini_set("display_errors", 1);
    session_start();
    require_once("../model/Conexion_BD.php");
    require_once("../model/Usuario.php");
    $usuario = $_POST['usuario'];
    $nombre = $_POST['nombre'];
    $aPaterno = $_POST['aPaterno'];
    $aMaterno = $_POST['aMaterno'];
    $contraseña = crypt($_POST['contraseña']);
    $id_tipo = $_POST['tipo'];
    $Usuario = new Usuario();
    $res = $Usuario->set_usuario($usuario,$contraseña,$nombre,$aPaterno,$aMaterno,$id_tipo);
    echo json_encode(array('resultado'=>$res));

?>