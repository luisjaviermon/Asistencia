<?php
    function string_pop(&$str){
        $last_char = substr($str, -1);
        $str = substr($str, 0, -1);
        return $last_char;
    }
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
    session_start();
    require_once("../model/Conexion_BD.php");
    require_once("../model/Usuario.php");
    $usuario = new Usuario();
    $row = $usuario->get_usuarios();
    $res = "";
    while($row){
        $usuario = array_pop($row);
        if($usuario['ROL']== 'USUARIO')
            $res = $usuario['USUARIO']."|".$res;
    }
    string_pop($res);
    $res = str_replace('"','',$res);
    print_r($res);
?>