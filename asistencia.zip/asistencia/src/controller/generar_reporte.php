<?php
    //error_reporting(E_ALL);
    //ini_set("display_errors", 1);
    date_default_timezone_set('UTC');
    session_start();
    require_once("../model/Conexion_BD.php");
    require_once("../model/Asistencia.php");
    require_once("../model/Usuario.php");
    $usuarios = $_GET['usuarios'];
    $fecha_inicio = $_GET['fecha_inicio'];
    $fecha_fin = $_GET['fecha_fin'];
    $asistencia_db = new Asistencia();
    $usuario_db = new Usuario();
    $results = array();
    $semanas = calcular_entre_semana($fecha_inicio,$fecha_fin);
    $asistencias=array();
    $rango = array();
    foreach($semanas as $semana){
        $prim = array_keys($semana);
        $rango[] = $semana[$prim[0]]." a ".$semana[$prim[count($prim)-1]];
    }
    $results['rango'] = $rango;
    foreach($usuarios as $usuario){
        $result = array();
        $usuario_obj = $usuario_db->get_usuario($usuario);
        $result['usuario'] = $usuario_obj['ID_USUARIO'];
        $result['nombre_completo'] = "$usuario_obj[NOMBRE] $usuario_obj[APELLIDO]";
        $result['horas_cumplidas'] = array();
        foreach($semanas as $semana){
            $horas_cumplidas = "00:00";
            foreach($semana as $dia){
                $asistencia = $asistencia_db->get_asistencia_fecha_usuario($dia,$usuario);
                if($asistencia != NULL){
                    foreach($asistencia as $asis){
                        $horas_cumplidas = sumar_horas($horas_cumplidas,$asis['HORAS_CUMPLIDAS']);
                    }
                }
            }
            $result['horas_cumplidas'][] = $horas_cumplidas;
        }
        $totales = "00:00";
        foreach($result['horas_cumplidas'] as $horas){
            $totales = sumar_horas($totales,$horas);
        }
        $result['totales']=$totales;
        $results['resultados'][] = $result;
    }
    echo json_encode($results);
    
    

    $reporte = array();
    //echo json_encode($results);
    

function sumar_horas($acumuladoTime, $nuevoTime){
    /*Tiempo acumulado*/
    $myArrayAcumuladoTime=explode(":", $acumuladoTime);

    $hrsAcumuladoTime=$myArrayAcumuladoTime[0];
    $minsAcumuladoTime=$myArrayAcumuladoTime[1];
    /*Nuevo Time*/
    $myArrayNewTime=explode(":", $nuevoTime);

    $hraNewTime=$myArrayNewTime[0];
    $minNewTime=$myArrayNewTime[1];
    /*Calculo*/
    $sumHrs=$hrsAcumuladoTime+$hraNewTime;
    $sumMins=$minsAcumuladoTime+$minNewTime;
    /*Si se pasan los MINUTOS*/
    if($sumMins>59){
      $sumMins-=60;
      $sumHrs+=1;
    }
    if($sumHrs < 10){
        $sumHrs = "0".$sumHrs;
    }
    if ($sumMins < 10){
        $sumMins = "0".$sumMins;
    }

    return "$sumHrs:$sumMins";
  }



    function get_rangos_semanas($semanas){
        $rangos = array();
        foreach($semanas as $semana){
            $rango = array();
            $rango['inicio'] = $semana[1];
            $rango['fin'] = $semana[count($semana)];
            $rangos[] = $rango;
        }
        return $rangos;
    }

    function calcular_entre_semana($fecha_inicio,$fecha_fin){
        $fecha_inicio = strtotime($fecha_inicio);
        $fecha_fin = strtotime($fecha_fin);
        $semanas = array();
        $semana = array();
        for($i=$fecha_inicio; $i<=$fecha_fin; $i+=86400){
            $dia = date('N', $i);
            if($dia==1){
                $semana['1'] = date("Y-m-d", $i);
            }
            if($dia==2){
                $semana['2'] = date("Y-m-d", $i);
            }
            if($dia==3){
                $semana['3'] = date("Y-m-d", $i);
            }
            if($dia==4){
                $semana['4'] = date("Y-m-d", $i);
            }
            if($dia==5){
                $semana['5'] = date("Y-m-d", $i);
                $semanas[] = $semana;
                $semana = array();
            }
        }
        if(count($semana)!=0){
            $semanas[] = $semana;
        }
        return $semanas;
    }
?>