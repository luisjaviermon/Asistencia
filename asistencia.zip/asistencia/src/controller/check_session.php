<?php
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
    session_start();
    if($_SESSION['loggedin']!= True || $_SESSION['expire'] < time()){
        http_response_code(401);
        echo json_encode(array('status'=>'sesion expirada o no iniciada'));
        require_once("../view/login.html");
        return 0;
    }else{
        http_response_code(200);
    }
?>