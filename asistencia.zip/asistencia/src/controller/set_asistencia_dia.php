<?php 
    date_default_timezone_set('UTC');
    session_start();
    require_once("../model/Conexion_BD.php");
    require_once("../model/Asistencia.php");
    require_once("../model/Horario.php");
    require_once("../model/Usuario.php");
    $horas_cumplidas = $_POST['horas_cumplidas'];
    $hora_entrada = $_POST['hora_entrada'];
    $hora_entrada = date_parse_from_format('Y-M-d H:i:s',$hora_entrada);
    $hora_entrada = date_format(new DateTime("$hora_entrada[year]-$hora_entrada[month]-$hora_entrada[day] $hora_entrada[hour]:$hora_entrada[minute]:$hora_entrada[second]"),'Y-m-d H:i:s');
    $hora_salida = date_format(calcular_hora_salida($hora_entrada,$horas_cumplidas,$horas_cumplidas),'Y-m-d H:i:s');
    $fecha = get_fecha_fecha_hora($hora_entrada)[0];
    $id_dia_entrada = get_dia_fecha($hora_entrada);
    $usuario_usuario = $_POST['usuario'];
    $usuario = new Usuario();
    $horario = new Horario();
    $asistencia = new Asistencia();
    $user = $usuario->get_usuario_usuario($usuario_usuario);
    $horarios = $horario->get_horario_usuario_dia($user['ID_USUARIO'],$id_dia_entrada);
    $id_horario = calcular_horario_mas_cercano($horarios,$hora_entrada);
    $asistencias_dia = $asistencia->get_asistencia_id_horario_fecha($id_horario,$fecha);
    
    if(validar_asistencia($asistencias_dia,$hora_entrada,$horas_cumplidas) == TRUE){
        try{
            $res = $asistencia->set_asistencia_fecha_usuario($fecha,$id_horario,$horas_cumplidas,$hora_entrada,$hora_salida,$horas_cumplidas,$user['ID_USUARIO']);
        }catch(Exception $e){
            $res = False;
        }
        
    }else{
        $res = False;
    }
    echo json_encode(array('Resultado'=>$res));

    function get_dia_fecha($fecha){
        return date("N",strtotime($fecha));
    }

    function calcular_hora_salida($hora_entrada,$horas_cumplidas, &$horas_cumplidas_arg){
        $dateTime = new DateTime($hora_entrada);
        $horas_cumplidas = preg_split("/[\s:]+/", $horas_cumplidas);
        if(intval($horas_cumplidas[0]) > 12){
            $horas_cumplidas[0] = "12";
            $horas_cumplidas[1] = "00";
            $horas_cumplidas[2] = "00";
            $horas_cumplidas_arg = "12:00";
        }            
        $dateTime->modify("+{$horas_cumplidas[0]} hours");
        $dateTime->modify("+{$horas_cumplidas[1]} minutes");
        $dateTime->modify("+{$horas_cumplidas[2]} seconds");
        return $dateTime;
    }

    function get_fecha_fecha_hora($date_time){
        return preg_split("/[\s ]+/", $date_time);
    }

    function calcular_horario_mas_cercano($horarios,$hora_entrada){
        $time = get_fecha_fecha_hora($hora_entrada)[1];
        $hora_entrada = preg_split("/[\s:]+/", $time)[0];
        $minuto_entrada = preg_split("/[\s:]+/", $time)[1];
        $hora_dif = 24;
        $min_dif = 60;
        foreach($horarios as $horario){
            $hora_horario = preg_split("/[\s:]+/", $horario['HORA_ENTRADA'])[0];
            $minuto_horario = preg_split("/[\s:]+/", $horario['HORA_ENTRADA'])[1];
            if(abs($hora_horario-$hora_entrada)<$hora_dif){
                $hora_dif = abs($hora_horario-$hora_entrada);
                $min_dif = abs($minuto_horario-$minuto_entrada);
                $horario_id = $horario['ID_HORARIO'];
            }else if(abs($hora_horario-$hora_entrada) == $hora_dif){
                if(abs($minuto_horario-$minuto_entrada) < $minuto_dif){
                    $min_dif = abs($minuto_horario-$minuto_entrada);
                    $horario_id = $horario['ID_HORARIO'];
                }
            }
        }
        return $horario_id;
    }
    function validar_asistencia($asistencias_dia,$hora_entrada,$horas_cumplidas){
        $hora_entrada = date_create($hora_entrada);
        if($horas_cumplidas == "00:00:00"){
            return false;
        }
        foreach($asistencias_dia as $asistencia_dia){
            $asistencia_dia['CHECK_SALIDA'] = date_create($asistencia_dia['CHECK_SALIDA']);
            if(intval(date_diff($asistencia_dia['CHECK_SALIDA'],$hora_entrada)->format("%R%h")) > 7 || intval(date_diff($asistencia_dia['CHECK_SALIDA'],$hora_entrada)->format("%R%h"))<0 || (intval(date_diff($hora_entrada,$asistencia_dia['CHECK_SALIDA'])->format("%R%h")) == 0 && intval(date_diff($asistencia_dia['CHECK_SALIDA'],$hora_entrada)->format("%R%I"))<0)){
                return False;
            }
        }
        return True;
    }
    // link de ejemplo: http://escuadron.intranet.ingenieria.unam.mx/vromero/asistencia/controller/set_asistencia_dia.php?hora_entrada=2018-11-09+12:00:00&horas_cumplidas=02:12:30&usuario=vromero
?>
