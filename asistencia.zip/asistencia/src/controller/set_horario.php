<?php
    //error_reporting(E_ALL);
    //ini_set("display_errors", 1);
    date_default_timezone_set('UTC');
    session_start();
    require_once("../model/Conexion_BD.php");
    require_once("../model/Horario.php");
    require_once("../model/Asistencia.php");
    $Horario = new Horario();
    $Asistencia = new Asistencia();
    $id_usuario = $_POST['id_usuario'];
    $horario_new = $_POST['horario'];
    $asistencias = $Asistencia->get_asistencia_usuario($id_usuario);
    $Horario->delete_horario($id_usuario);
    $status_horario = False;
    foreach ($horario_new as $horario) {
        $horas_obligatorias = date_diff(date_create($horario['hora_entrada']),date_create($horario['hora_salida']))->format("%H:%I:%S");
        if($horario['hora_entrada'] == '' || $horario['hora_salida'] == '' || $horario['id_dia'] == ''){
            break;
        }
        $status_horario = $Horario->set_horario($id_usuario,$horario['hora_entrada'],$horario['hora_salida'],$horario['id_dia'],$horas_obligatorias);
        if($status_horario == False){
            break;
        }
    }
    $horarios = $Horario->get_horarios_usuario($id_usuario);
    $status_asistencia = True;
    foreach($asistencias as $asistencia){
        $hora_entrada = $asistencia['CHECK_ENTRADA'];
        $time = get_fecha_fecha_hora($hora_entrada)[1];
        $hora_entrada = preg_split("/[\s:]+/", $time)[0];
        $minuto_entrada = preg_split("/[\s:]+/", $time)[1];
        $hora_dif = 24;
        $min_dif = 60;
        foreach($horarios as $horario){
            $hora_horario = preg_split("/[\s:]+/", $horario['HORA_ENTRADA'])[0];
            $minuto_horario = preg_split("/[\s:]+/", $horario['HORA_ENTRADA'])[1];
            if(abs($hora_horario-$hora_entrada)<$hora_dif){
                $hora_dif = abs($hora_horario-$hora_entrada);
                $min_dif = abs($minuto_horario-$minuto_entrada);
                $horario_id = $horario['ID_HORARIO'];
            }else if(abs($hora_horario-$hora_entrada) == $hora_dif){
                if(abs($minuto_horario-$minuto_entrada) < $min_dif){
                    $min_dif = abs($minuto_horario-$minuto_entrada);
                    $horario_id = $horario['ID_HORARIO'];
                }
            }
            $status_asistencia = $Asistencia->update_horario($asistencia['ID_ASISTENCIA'],$horario_id);
        }
    }
    echo json_encode(array('status_horario'=>$status_horario,'status_asistencia'=>$status_asistencia));
    function get_fecha_fecha_hora($date_time){
        return preg_split("/[\s ]+/", $date_time);
    }
?>