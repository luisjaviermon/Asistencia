<?php 
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
    date_default_timezone_set('UTC');
    require_once("../model/Conexion_BD.php");
    require_once("../model/Reporte.php");
    $id_usuario = $_GET['id_usuario'];
    $Reporte = new Reporte();
    $row = $Reporte->get_reporte_actividad_by_usuario($id_usuario);
    echo json_encode($row);
?>
