<?php
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
    require_once("check_session.php");
    require_once("../model/Conexion_BD.php");
    require_once("../model/Asistencia.php");
    require_once("../model/Usuario.php");
    $asistencia = new Asistencia();
    $usuario = new Usuario();
    if($_SESSION['tipo'] == 3){
        $row = $asistencia->get_asistencia_usuario($_SESSION['id']);
        echo json_encode($row);
    }else if($_SESSION['tipo'] < 3){
        $row = $asistencia->get_asistencia_all();
        echo json_encode($row);
    }
?>
