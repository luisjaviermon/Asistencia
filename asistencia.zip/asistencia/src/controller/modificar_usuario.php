<?php 
    //error_reporting(E_ALL);
    //ini_set("display_errors", 1);
    require_once("check_session.php");
    require_once("../model/Conexion_BD.php");
    require_once("../model/Usuario.php");
    $id_usuario = $_POST['id_usuario'];
    $usuario = $_POST['usuario'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $id_tipo = $_POST['tipo'];
    $Usuario = new Usuario();
    $res = $Usuario->update_usuario($id_usuario,$usuario,$nombre,$apellido,$id_tipo);
    echo json_encode(array('resultado'=>$res));
?>