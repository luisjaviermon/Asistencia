<?php
    class Horario{
        private $db;
        private $horarios;
        function __construct(){
            $this->horarios = array();
            $this->db=Conexion::connect();
        }

        function get_horario_usuario_dia($id_usuario,$id_dia){
            $horario = array();
            $consulta=$this->db->query("SELECT * FROM HORARIO WHERE ID_USUARIO=$id_usuario AND ID_DIA=$id_dia;");
            if($consulta->num_rows > 0){
                while($filas = $consulta->fetch_assoc()){
                    $horario[] = $filas;
                }
            }else{
                $consulta=$this->db->query("SELECT * FROM HORARIO WHERE ID_USUARIO=$id_usuario;");
                while($filas = $consulta->fetch_assoc()){
                    $horario[] = $filas;
                }  
            }
            return $horario;
        }

        function delete_horario($id_usuario){
            $consulta = $this->db->query("DELETE FROM HORARIO WHERE ID_USUARIO=$id_usuario;");
            if($consulta == True){
                return True;
            }
            return False;
        }
        
        function set_horario($id_usuario,$hora_entrada,$hora_salida,$id_dia,$horas_obligatorias){
            $consulta = $this->db->query("INSERT INTO HORARIO (ID_USUARIO, HORA_ENTRADA, HORA_SALIDA, HORAS_OBLIGATORIAS, ID_DIA) VALUES ($id_usuario,'$hora_entrada','$hora_salida','$horas_obligatorias',$id_dia);");
            if($consulta == True){
                return True;
            }
            return False;
        }
        
        function get_horarios_usuario($id_usuario){
            $horario = array();
            $consulta = $this->db->query("SELECT * FROM HORARIO WHERE ID_USUARIO=$id_usuario;");
            while($filas = $consulta->fetch_assoc()){
                $horario[] = $filas;
            }
            return $horario;
        }

        function get_dias_semana(){
            $dias_semana = array();
            $consulta = $this->db->query("SELECT * FROM DIA_SEMANA");
            while($filas = $consulta->fetch_assoc()){
                $dias_semana[]=$filas;
            }
            return $dias_semana;
        }

        function get_horario_usuario($id_usuario, $id_dia){
            $consulta=$this->db->query("SELECT * FROM HORARIO WHERE ID_USUARIO=$id_usuario AND ID_DIA=$id_dia;");
            if( $consulta->num_rows > 0){
                $row = $consulta->fetch_array(MYSQLI_ASSOC);
                return $row;
            } else {
                return false;
            }
        }
    }
?>