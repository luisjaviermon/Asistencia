<?php
    class Conexion{
        public static function connect(){
            $conexion = new mysqli("localhost","vromero","nomad123","asistencia");
            $conexion->query("SET NAME 'utf8'");
            $conexion->query("SET CHARACTER SET utf8;");
            return $conexion;
        }
    }
?>