<?php
    class Asistencia{
        private $db;
        function __construct(){
            $this->db=Conexion::connect();
        }

        function set_asistencia_fecha_usuario($fecha,$id_horario,$horas_cumplidas,$hora_entrada,$hora_salida,$horas_cumplidas,$id_usuario){
            $consulta = $this->db->query("INSERT INTO ASISTENCIA (FECHA, ID_HORARIO, CHECK_ENTRADA, CHECK_SALIDA, HORAS_CUMPLIDAS, ID_USUARIO) VALUES ('$fecha',$id_horario,'$hora_entrada','$hora_salida','$horas_cumplidas',$id_usuario)");
            if($consulta == TRUE){
                return TRUE;
            }else{
                return FALSE;
            }
            return FALSE;
        }

        function get_asistencia_fecha_usuario($fecha,$id_usuario){
            $asistencias = array();
            $consulta = $this->db->query("SELECT ASISTENCIA.ID_ASISTENCIA,ASISTENCIA.CHECK_ENTRADA,ASISTENCIA.CHECK_SALIDA,ASISTENCIA.HORAS_CUMPLIDAS,ASISTENCIA.FECHA,USUARIO.USUARIO,HORARIO.ID_HORARIO FROM ASISTENCIA INNER JOIN HORARIO ON HORARIO.ID_HORARIO = ASISTENCIA.ID_HORARIO INNER JOIN USUARIO ON HORARIO.ID_USUARIO = USUARIO.ID_USUARIO WHERE USUARIO.ID_USUARIO = $id_usuario AND ASISTENCIA.FECHA='$fecha'");
            while($filas = $consulta->fetch_assoc()){
                $asistencias[]=$filas;
            }
            return $asistencias;
        }

        function get_asistencia_id_horario_fecha($id_horario,$fecha){
            $asistencias = array();
            $consulta = $this->db->query("SELECT * FROM ASISTENCIA WHERE ID_HORARIO=$id_horario AND FECHA='$fecha'");
            while($filas = $consulta->fetch_assoc()){
                $asistencias[]=$filas;
            }
            return $asistencias;
        }

        function update_horario($id_asistencia,$id_horario){
            $consulta = $this->db->query("UPDATE ASISTENCIA SET ID_HORARIO=$id_horario WHERE ID_ASISTENCIA=$id_asistencia;");
            if($consulta == True){
                return True;
            }
            echo $consulta->error;
            return False;
        }

        function get_asistencia_usuario($id_usuario){
            $asistencias = array();
            $consulta = $this->db->query("SELECT ASISTENCIA.ID_ASISTENCIA,ASISTENCIA.CHECK_ENTRADA,ASISTENCIA.CHECK_SALIDA,HORARIO.HORA_ENTRADA,HORARIO.HORA_SALIDA,ASISTENCIA.HORAS_CUMPLIDAS,ASISTENCIA.FECHA,USUARIO.USUARIO FROM ASISTENCIA INNER JOIN USUARIO ON ASISTENCIA.ID_USUARIO = USUARIO.ID_USUARIO INNER JOIN HORARIO ON HORARIO.ID_HORARIO = ASISTENCIA.ID_HORARIO WHERE USUARIO.ID_USUARIO = $id_usuario ");
            while($filas = $consulta->fetch_assoc()){
                $asistencias[]=$filas;
            }
            return $asistencias;
        }

        function get_asistencia_all(){
            $asistencias = array();
            $consulta = $this->db->query("SELECT ASISTENCIA.ID_ASISTENCIA,ASISTENCIA.CHECK_ENTRADA,ASISTENCIA.CHECK_SALIDA,HORARIO.HORA_ENTRADA,HORARIO.HORA_SALIDA,ASISTENCIA.HORAS_CUMPLIDAS,ASISTENCIA.FECHA,USUARIO.USUARIO FROM ASISTENCIA INNER JOIN USUARIO ON ASISTENCIA.ID_USUARIO = USUARIO.ID_USUARIO INNER JOIN HORARIO ON HORARIO.ID_HORARIO = ASISTENCIA.ID_HORARIO");
            
            while($filas = $consulta->fetch_assoc()){
                $asistencias[]=$filas;
            }
            return $asistencias;
        }

        function check_entrada($token_entrada){

        }
        function check_salida($token_salida){
            
        }
    }
?>