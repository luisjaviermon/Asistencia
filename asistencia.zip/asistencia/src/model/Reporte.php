<?php
    class Reporte{
        private $id_usuario;
        private $fecha;
        private $db;
        function __construct(){
            $this->id_usuario = NULL;
            $this->fecha = NULL;
            $this->db=Conexion::connect();
        }

        function get_id_asistencia($fecha,$id_usuario){

        }

        function calcular_horas_totales(){

        }

        function calcular_horas_dia(){

        }

        function calcular_horas_semana(){

        }

        function get_reporte_actividad_by_usuario($id_usuario){
            $horario = array();
            $consulta = $this->db->query("SELECT ACTIVIDAD.PROGRAMA, ACTIVIDAD.TIEMPO, ACTIVIDAD.INFO, ASISTENCIA.FECHA FROM ACTIVIDAD INNER JOIN ASISTENCIA ON ASISTENCIA.ID_ASISTENCIA = ACTIVIDAD.ID_ACTIVIDAD WHERE ASISTENCIA.ID_USUARIO=$id_usuario;");
            while($filas = $consulta->fetch_assoc()){
                $horario[] = $filas;
            }
            return $horario;
        }

        function set_reporte_actividad($id_asistencia,$programa,$tiempo,$info){
            $consulta = $this->db->query("INSERT INTO ACTIVIDAD (ID_ACTIVIDAD, ID_ASISTENCIA, PROGRAMA, TIEMPO, INFO) VALUES ('$id_asistencia$programa',$id_asistencia,'$programa','$tiempo','$info');");
            if($consulta == True){
                return True;
            }
            return False;
        }
    }   
?>