<?php
    class Usuario{
        private $nombre;
        private $aPaterno;
        private $aMaterno;
        private $usuario;
        private $contraseña;
        private $db;
        function __construct(){
            $this->db=Conexion::connect();
        }


        function set_usuario($usuario,$nombre,$apellido,$id_tipo){
            $consulta = $this->db->query("INSERT INTO USUARIO (USUARIO, NOMBRE, APELLIDO, ID_TIPO) VALUES ('$usuario','$nombre','$apellido',$id_tipo)");
            if($consulta == TRUE){
                return TRUE;
            }else{
                return FALSE;
            }
            return FALSE;
        }

        function get_usuario_usuario($usuario){
            $usuarios = array();
            $consulta=$this->db->query("SELECT USUARIO.ID_USUARIO, USUARIO.NOMBRE, USUARIO.APELLIDO, USUARIO.USUARIO,TIPO.ID_TIPO,TIPO.NOMBRE AS ROL FROM `USUARIO` INNER JOIN TIPO ON USUARIO.ID_TIPO = TIPO.ID_TIPO WHERE USUARIO='$usuario'");
            if( $consulta->num_rows > 0){
                $row = $consulta->fetch_array(MYSQLI_ASSOC);
                return $row;
            } else {
                return false;
            }
        }

        function get_usuarios(){
            $usuarios = array();
            $consulta=$this->db->query("SELECT USUARIO.ID_USUARIO, USUARIO.NOMBRE,USUARIO.APELLIDO,USUARIO.USUARIO,TIPO.ID_TIPO,TIPO.NOMBRE AS ROL FROM `USUARIO` INNER JOIN TIPO ON USUARIO.ID_TIPO = TIPO.ID_TIPO");
            while($filas = $consulta->fetch_assoc()){
                $usuarios[] = $filas;
            }
            return $usuarios;
        }

        function get_tipo_usuario(){
            $tipos = array();
            $consulta=$this->db->query("SELECT * FROM TIPO");
            while($filas=$consulta->fetch_assoc()){
                $tipos[]=$filas;
            }
            return $tipos;
        }

        function check_login($usuario){
            $consulta=$this->db->query("SELECT * FROM USUARIO WHERE USUARIO='$usuario'");
            if( $consulta->num_rows > 0){
                $row = $consulta->fetch_array(MYSQLI_ASSOC);
                return $row;
            } else {
                return false;
            }
        }

        function get_usuario($id_usuario){
            $consulta=$this->db->query("SELECT USUARIO.ID_USUARIO, USUARIO.NOMBRE,USUARIO.APELLIDO,USUARIO.USUARIO,TIPO.ID_TIPO,TIPO.NOMBRE AS ROL FROM `USUARIO` INNER JOIN TIPO ON USUARIO.ID_TIPO = TIPO.ID_TIPO WHERE ID_USUARIO=$id_usuario");
            if( $consulta->num_rows > 0){
                $row = $consulta->fetch_array(MYSQLI_ASSOC);
                return $row;
            } else {
                return false;
            }
        }

        function delete_usuario($id_usuario){
            $query = "DELETE FROM USUARIO WHERE ID_USUARIO=$id_usuario";
            $consulta=$this->db->query($query);
            if($consulta == True){
                return True;
            }
            return False;
        }

        function update_usuario($id_usuario,$usuario,$nombre,$apellido,$id_tipo){
            $query = "UPDATE USUARIO SET USUARIO.USUARIO='$usuario', USUARIO.NOMBRE='$nombre', USUARIO.APELLIDO='$apellido', USUARIO.ID_TIPO=$id_tipo WHERE USUARIO.ID_USUARIO=$id_usuario";
            $consulta=$this->db->query($query);
            if($consulta == True){
                return True;
            }
            return False;
        }
    }
?>