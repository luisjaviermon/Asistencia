#!/bin/bash
mes_actual=$(LANG=en_US date +%b)
dia_actual=$(date +%d)
dia_actual=$(date +%d | gawk -F0 '{print $2}')
usernames=$(curl https://192.168.130.139/vromero/asistencia/controller/get_usernames.php -k)
last -wF :0 tty7 | egrep "$usernames" | egrep -i "$mes_actual *$dia_actual"> sesion.txt
while read linea; do
    linea=$( echo -e   "${linea/:0           0.0.0.0          / | }")
    tiempoContado=$(echo -e "$linea" | cut -f 2 -d "(" | cut -f 1 -d ")")
    if [[ !($tiempoContado =~ "still logged in") && !($tiempoContado =~ "gone - no logout") ]] ; then
        nombre=$(echo -e "$linea" | gawk -F' ' '{print $1} ')
        entrada=$(echo -e "$linea" | gawk -F' ' '{print $7} ')
        dia=$(echo -e "$linea" | gawk -F' ' '{print $6} ')
        mes=$(echo -e "$linea" | gawk -F' ' '{print $5} ')
        duracion=$(echo -e "$linea" | gawk -F' ' '{print $10} ' | cut -f 2 -d "(" | cut -f 1 -d ")")
        anio=$(date | gawk -F' ' '{print $6}' )
        mes2=$(date +%m  | gawk -F' ' '{print $1}' )
        salida="user=$nombre&fecha_entrada=$anio-$mes-$dia+$entrada&horas_cumplidas=$tiempoContado:00";
        curl -k "https://192.168.130.139/vromero/asistencia/controller/set_asistencia_dia.php" -X POST -d "hora_entrada=$anio-$mes-$dia+$entrada&horas_cumplidas=$tiempoContado:00&usuario=$nombre"
    fi
done < sesion.txt
## tiene que generar una salida asi: "user=usuario&fecha_entrada=yyyy-mm-dd+hh:mm:ss&horas_cumlidas=hh:mm:ss"