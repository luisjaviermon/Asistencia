$(document).ready(function () {
    index = function () {
        $(".contenido").html("");
        $(".breadcrumb").html("<li class='breadcrumb-item'><a href='#'>Panel</a></li><li class='breadcrumb-item active'>Inicio</li>");
    }
    if (sessionStorage.getItem("tipo") > 1) {
        $(".registrar-usuario").hide();
        $("#span-list-usuario").text("Ver usuario");
        $("#span-horario").text("ver horario");
    }

    function iniciar_sesion(usr, pass) {
        $.ajax({
            type: "POST",
            url: "controller/get_sesion.php",
            data: {
                usuario: usr,
                contraseña: pass
            },
            dataType: "json",
            statusCode: {
                200: function (XHTMLHttpRequest) {
                    respuesta = XHTMLHttpRequest;
                    if (respuesta.tipo != -1) {
                        sessionStorage.setItem("usuario", respuesta.usuario);
                        sessionStorage.setItem("tipo", respuesta.tipo);
                        sessionStorage.setItem("id", respuesta.id);
                        location.href = "index.php";
                    } else {
                        alert("usuario o contraseña no validos");
                    }
                },
                401: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        });
    }

    $(".iniciar-sesion").click(function () {
        $.ajax({
            type: "GET",
            url: "controller/set_sesion.php",
            data: {
                usuario: $("#user").val(),
                contraseña: $("#contra").val()
            },
            dataType: "json",
            statusCode: {
                200: function (XHTMLHttpRequest) {
                    respuesta = XHTMLHttpRequest;
                    if (respuesta.status == 0) {
                        location.href = "index.php";
                        location.reload();

                    } else if (respuesta.status == -1) {
                        alert("Usuario o contraseña no validos");
                    }
                },
                401: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        });
    });
    function registrar_usuario_commit() {
        if ($("#contraseña").val() != $("#contraseña2").val()) {
            alert("Las contraseñas no son iguales");
            return;
        }
        if (!$("#nombre").val() || !$("#usuario").val() || !$("#contraseña").val() || !$("#apellido").val()) {
            alert("te faltan llenar campos");
            return;
        }
        if ($("#contraseña").val().length < 6) {
            alert("la contraseña debe ser mayor a 6 caracteres");
            return;
        }
        if ($("#usuario").val().length < 6) {
            alert("el nombre de usuario debe ser mayor a 6 caracteres");
            return;
        }
        $.ajax({
            type: "POST",
            url: "controller/registrar_usuario.php",
            data: {
                usuario: $("#usuario").val(),
                nombre: $("#nombre").val(),
                apellido: $("#apellido").val(),
                contraseña: $("#contraseña").val(),
                tipo: $("#tipo option:selected").val()
            },
            dataType: "json",
            statusCode: {
                200: function (XHTMLHttpRequest) {
                    respuesta = XHTMLHttpRequest;
                    if (respuesta.resultado == true) {
                        alert("Usuario registrado con exito");
                        location.href = "index.php";
                        location.reload();
                    } else {
                        alert("Error en el registro de usuario");
                    }
                    ver_usuarios();
                },
                401: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        });
    }

    function registrar_usuario() {
        $(".active").removeClass("active");
        $(".registrar-usuario").addClass("active");
        $(".contenido").load("view/registrar_usuario.html");
        $(".breadcrumb").html("<li class='breadcrumb-item'><a href='#'>Panel</a></li><li class='breadcrumb-item active'>Registrar usuario</li>");
        get_tipo_usuario();
    }

    function get_tipo_usuario() {
        $.ajax({
            type: "GET",
            url: "controller/get_tipo_usuario.php",
            dataType: "json",
            async: false,
            statusCode: {
                200: function (data) {
                    tipo = data.pop();
                    $("#tipo").append("<option value=''>Tipo de Usuario</option>");
                    while (tipo) {
                        $("#tipo").append("<option id='id-tipo-" + tipo.ID_TIPO + "' value='" + tipo.ID_TIPO + "'>" + tipo.NOMBRE + "</option>");
                        tipo = data.pop();
                    }
                },
                401: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        });
    }

    function eliminar_usuario(id_usuario) {
        $.ajax({
            type: "POST",
            url: "controller/delete_usuario.php",
            data: {
                id_usuario: id_usuario
            },
            dataType: "json",
            statusCode: {
                200: function (XHTMLHttpRequest) {
                    res = XHTMLHttpRequest;
                    if (res.resultado == true) {
                        alert("Usuario eliminado con exito");
                    } else {
                        alert("Error en la eliminacion del usuario");
                    }
                },
                401: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        });
    }

    function eliminar_usuario_commit() {
        id_usuario = $(this).attr('id');
        eliminar_usuario(id_usuario);
        ver_usuarios();
    }



    function ver_usuarios() {
        $(".active").removeClass("active");
        $(".modificar-usuario").addClass("active");
        $(".contenido").load("view/ver_usuarios.html");
        $(".breadcrumb").html("<li class='breadcrumb-item'><a href='#'>Panel</a></li><li class='breadcrumb-item active'>Modificar usuario</li>");
        $.ajax({
            type: "GET",
            url: "controller/get_usuarios.php",
            async: false,
            dataType: "json",
            statusCode: {
                200: function (data) {
                    usuarios = data;
                    usuario = usuarios.pop();
                    while (usuario) {
                        tipo = sessionStorage.getItem("tipo");
                        if (tipo == 1) {
                            $("#tbl-bdy").append('<tr id=tr-usr' + usuario.ID_USUARIO + "><td>" + usuario.NOMBRE + "</td><td>" + usuario.APELLIDO + "</td><td>" + usuario.USUARIO + "</td><td>" + usuario.ROL + "</td><td><button class='modificar-usr btn btn-warning btn-block' id=" + usuario.ID_USUARIO + ">Modificar</button><button class='eliminar-usr btn btn-danger btn-block' id=" + usuario.ID_USUARIO + ">Eliminar</button></td></tr>");
                        } else {
                            $("#tbl-bdy").append('<tr id=tr-usr' + usuario.ID_USUARIO + "><td>" + usuario.NOMBRE + "</td><td>" + usuario.APELLIDO + "</td><td>" + usuario.USUARIO + "</td><td>" + usuario.ROL + "</td><td><button class='ver-usr btn btn-success btn-block' id=" + usuario.ID_USUARIO + ">Ver</button></td></tr>");
                        }
                        usuario = usuarios.pop();
                    }
                    $('#dataTable').DataTable();
                    $(".ver-usr").click(function () {
                        id_usuario = get_usuario($(this).attr('id'));
                        Usuario = get_usuario(id_usuario);
                        $(".breadcrumb").html("<li class='breadcrumb-item'><a href='#'>Panel</a></li><li class='breadcrumb-item'>Modificar usuario</li><li class='breadcrumb-item active'>Ver</li>");
                        $(".contenido").load("view/ver_usuario.html", Usuario, function () {
                            get_tipo_usuario();
                            $("#usuario").val(Usuario.USUARIO);
                            $("#usuario").prop('disabled', true);
                            $("#nombre").val(Usuario.NOMBRE);
                            $("#nombre").prop('disabled', true);
                            $("#apellido").val(Usuario.APELLIDO);
                            $("#apellido").prop('disabled', true);
                            $(".contraseña").hide();
                            $('#id-tipo-' + Usuario.ID_TIPO).attr('selected', 'selected');
                            $("#tipo").prop('disabled', true);
                            $("#id_usuario").val(Usuario.ID_USUARIO);

                        });
                    });
                },
                401: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        })
    }


    function modificar_usuario_view() {
        Usuario = get_usuario($(this).attr('id'));
        $(".breadcrumb").html("<li class='breadcrumb-item'><a href='#'>Panel</a></li><li class='breadcrumb-item'>Modificar usuario</li><li class='breadcrumb-item active'>Modificar</li>");
        $(".contenido").load("view/ver_usuario.html", Usuario, function () {
            get_tipo_usuario();
            $("#usuario").val(Usuario.USUARIO);
            $("#nombre").val(Usuario.NOMBRE);
            $("#apellido").val(Usuario.APELLIDO);
            $('#id-tipo-' + Usuario.ID_TIPO).attr('selected', 'selected');
            $("#id_usuario").val(Usuario.ID_USUARIO);
        });
    }



    function get_usuario(id_usuario) {
        usuario = "";
        $.ajax({
            type: "GET",
            async: false,
            url: "controller/get_usuario.php",
            data: {
                id: id_usuario
            },
            dataType: "json",
            statusCode: {
                200: function (XHTMLHttpRequest) {
                    usuario = XHTMLHttpRequest;
                },
                401: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        });
        return usuario;
    }

    function ver_usuario_reg_horarios() {
        $(".active").removeClass("active");
        $(".registrar-horario").addClass("active");
        $(".contenido").load("view/ver_usuarios.html");
        $(".breadcrumb").html("<li class='breadcrumb-item'><a href='#'>Panel</a></li><li class='breadcrumb-item active'>Registrar Horario</li>");
        $.ajax({
            type: "GET",
            url: "controller/get_usuarios.php",
            dataType: "json",
            statusCode: {
                200: function (XHTMLHttpRequest) {
                    usuarios = XHTMLHttpRequest;
                    usuario = usuarios.pop();
                    while (usuario) {
                        if (usuario.ROL == 'USUARIO')
                            if (sessionStorage.getItem('tipo') == 2)
                                $("#tbl-bdy").append('<tr id=tr-usr' + usuario.ID_USUARIO + "><td>" + usuario.NOMBRE + "</td><td>" + usuario.APELLIDO + "</td><td>" + usuario.USUARIO + "</td><td>" + usuario.ROL + "</td><td><button class='ver-horario-usr btn btn-success btn-block' id=" + usuario.ID_USUARIO + ">Ver Horario</button></td></tr>");
                            else
                                $("#tbl-bdy").append('<tr id=tr-usr' + usuario.ID_USUARIO + "><td>" + usuario.NOMBRE + "</td><td>" + usuario.APELLIDO + "</td><td>" + usuario.USUARIO + "</td><td>" + usuario.ROL + "</td><td><button class='reg-horario-usr btn btn-warning btn-block' id=" + usuario.ID_USUARIO + ">Registrar Horario</button></td></tr>");
                        usuario = usuarios.pop();
                    }
                    $('#dataTable').DataTable();
                },
                401: function (XHTMLHttpRequest) {
                    alert("sesion expirada o no autorizado");
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        });
    }

    function ver_usuario_actividad() {
        $(".active").removeClass("active");
        $(".reporte-actividad").addClass("active");
        $(".contenido").load("view/ver_usuarios.html");
        $(".breadcrumb").html("<li class='breadcrumb-item'><a href='#'>Panel</a></li><li class='breadcrumb-item active'>Actividad de Usuarios</li>");
        $.ajax({
            type: "GET",
            url: "controller/get_usuarios.php",
            dataType: "json",
            statusCode: {
                200: function (XHTMLHttpRequest) {
                    usuarios = XHTMLHttpRequest;
                    usuario = usuarios.pop();
                    while (usuario) {
                        if (usuario.ROL == 'USUARIO')
                            $("#tbl-bdy").append('<tr id=tr-usr' + usuario.ID_USUARIO + "><td>" + usuario.NOMBRE + "</td><td>" + usuario.APELLIDO + "</td><td>" + usuario.USUARIO + "</td><td>" + usuario.ROL + "</td><td><button class='definir-actividad-usr btn btn-success btn-block' id=" + usuario.ID_USUARIO + ">Ver Actividad</button></td></tr>");
                        usuario = usuarios.pop();
                    }
                    $('#dataTable').DataTable();
                },
                401: function (XHTMLHttpRequest) {
                    alert("sesion expirada o no autorizado");
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        });

    }
    //Esta funcion es la de dias
    function get_dias_semana() {
        $.ajax({
            type: "GET",
            url: "controller/get_dias_semana.php",
            async: false,
            dataType: "json",
            statusCode: {
                200: function (XHTMLHttpRequest) {
                    $(".dia-semana option").remove();
                    dias_semana = XHTMLHttpRequest.sort();
                    dia_semana = dias_semana.pop();

                    $(".dia-semana").append("<option id='dia-semana-0' value='0'>Dia de la semana</option>");
                    while (dia_semana) {
                        $(".dia-semana").append("<option id='dia-semana-" + dia_semana.ID_DIA + "' value='" + dia_semana.ID_DIA + "'>" + dia_semana.NOMBRE_DIA + "</option>");
                        dia_semana = dias_semana.pop();
                    }
                },
                401: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        });
    }

    function set_nombre_usuario(id_usuario) {
        $.ajax({
            type: "GET",
            url: "controller/get_usuario.php",
            data: {
                id: id_usuario
            },
            async: false,
            dataType: "json",
            statusCode: {
                200: function (XHTMLHttpRequest) {
                    $("#usuario").text = XHTMLHttpRequest.USUARIO;
                    $("#id_usuario").val(XHTMLHttpRequest.ID_USUARIO);
                },
                401: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        });
    }
    function modificar_usuario_commit() {
        if ($("#contraseña").val() != $("#contraseña2").val()) {
            alert("Las contraseñas no son iguales");
            return;
        }
        if (!$("#nombre").val() || !$("#usuario").val() || !$("#apellido").val()) {
            alert("te faltan llenar campos");
            return;
        }
        if ($("#usuario").val().length < 6) {
            alert("el nombre de usuario debe ser mayor a 6 caracteres");
            return;
        }
        $.ajax({
            type: "POST",
            url: "controller/modificar_usuario.php",
            data: {
                id_usuario: $("#id_usuario").val(),
                usuario: $("#usuario").val(),
                nombre: $("#nombre").val(),
                apellido: $("#apellido").val(),
                contraseña: $("#contraseña").val(),
                tipo: $("#tipo option:selected").val()
            },
            dataType: "json",
            statusCode: {
                200: function (XHTMLHttpRequest) {
                    respuesta = XHTMLHttpRequest;
                    if (respuesta.resultado == true) {
                        alert("Usuario modificado con exito");
                        ver_usuarios();
                    } else {
                        alert("Error modificando usuario");
                    }
                },
                401: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        });
    }
    function login() {
        iniciar_sesion($("#user").val(), $("#contra").val());
    }
    function commit_horario() {
        $.ajax({
            type: "POST",
            url: "controller/set_horario.php",
            data: get_reg_horario(),
            dataType: "json",
            statusCode: {
                200: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest.status_asistencia == true && XHTMLHttpRequest.status_horario == true) {
                        alert("exito en el registro del horario");
                        ver_usuario_reg_horarios();
                    }
                },
                401: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                    alert("Error en el registro de horario");
                }
            }
        });
    }
    function add_reg_dia() {
        $("#tbl-bdy").append("<tr><td class='td-hora-entrada-horario'><input type='text' id='hora_inicio' class='time form-control hora_inicio' placeholder='Hora de entrada' required='required'></td><td class='td-hora-salida-horario'><input type='text' id='hora_fin' class='time form-control hora_fin' placeholder='Hora de salida' required='required'></td><td class='td-dia-horario'><select id='dia-semana' class='dia-semana form-control dia-semana' required='required'></select></td></tr>");
        get_dias_semana();
        $(".dia-semana").attr('class', 'dia-semana-checked form-control')
        $('.time').timepicker({
            'timeFormat': 'H:i:s',
            'disableTimeRanges': [
                ['12am', '9am'],
                ['8pm', '24pm']
            ],
            'step': 15
        });
    }

    function del_reg_dia() {
        length = ($("#tbl-bdy tr").length);
        $("#tbl-bdy tr")[length - 1].remove();
    }


    function get_horario_completo_usuario(id_usuario) {
        horario = "";
        $.ajax({
            type: "GET",
            url: "controller/get_horario_completo_usuario.php",
            async: false,
            data: {
                id_usuario: id_usuario
            },
            dataType: "json",
            statusCode: {
                200: function (XHTMLHttpRequest) {
                    horario = XHTMLHttpRequest;
                },
                401: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        });
        return horario;
    }
    function get_asistencias() {
        asistencias = "";
        $.ajax({
            type: "GET",
            url: "controller/get_asistencia.php",
            dataType: "json",
            async: false,
            statusCode: {
                200: function (XHTMLHttpRequest) {
                    asistencias = XHTMLHttpRequest;
                },
                401: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        });
        return asistencias;
    }
    function ver_horario() {
        var id_usuario = $(this).attr('id');
        var horario_usuario = get_horario_completo_usuario($(this).attr("id"));
        $(".contenido").load("view/ver_horario_usuario.html", horario_usuario, function () {
            set_nombre_usuario(id_usuario);
            horygrand = horario_usuario['horario'];
            horygrand.forEach(hory => {
                add_reg_dia();
            });
            $(".control-dias").hide();
            hory = horygrand.pop();
            $.each($("#tbl-bdy tr"), function (indexInArray, valueOfElement) {
                if (hory) {
                    valueOfElement['children'][2]['children'][0].value = hory['id_dia'];
                    valueOfElement['children'][2]['children'][0].className = 'dia-semana-checked form-control';
                    valueOfElement['children'][0]['children'][0].value = hory['hora_entrada'];
                    valueOfElement['children'][1]['children'][0].value = hory['hora_salida'];
                    hory = horygrand.pop();
                }
            });
            $(".dia-semana-checked").prop("disabled", true);
            $(".hora_inicio").prop("disabled", true);
            $(".hora_fin").prop("disabled", true);
            $(".btn-commit-horario").addClass("registrar-horario");
            $(".btn-commit-horario").text("Regresar");
            $(".registrar-horario").removeClass("btn-commit-horario");
        });
    }
    function registrar_horario() {
        var id_usuario = $(this).attr('id');

        var horario_usuario = get_horario_completo_usuario($(this).attr("id"));
        $(".contenido").load("view/ver_horario_usuario.html", horario_usuario, function () {
            set_nombre_usuario(id_usuario);
            horygrand = horario_usuario['horario'];
            horygrand.forEach(hory => {
                add_reg_dia();
            });
            hory = horygrand.pop();
            $.each($("#tbl-bdy tr"), function (indexInArray, valueOfElement) {
                if (hory) {
                    valueOfElement['children'][2]['children'][0].value = hory['id_dia'];
                    valueOfElement['children'][2]['children'][0].className = 'dia-semana-checked form-control';
                    valueOfElement['children'][0]['children'][0].value = hory['hora_entrada'];
                    valueOfElement['children'][1]['children'][0].value = hory['hora_salida'];
                    hory = horygrand.pop();
                }
            });
        });
    }
    function get_usuarios() {
        usuarios = "";
        $.ajax({
            type: "GET",
            url: "controller/get_usuarios.php",
            dataType: "json",
            async: false,
            statusCode: {
                200: function (XHTMLHttpRequest) {
                    usuarios = XHTMLHttpRequest;
                },
                401: function (XHTMLHttpRequest) {
                    if (XHTMLHttpRequest == false) {
                        location.href = "index.php";
                    }
                    location.href = "index.php";
                }
            }
        });
        return usuarios;
    }
    function generar_reporte() {
        usuarios = [];
        $('#id_usuario option').each(function (i) {
            if (this.selected == true) {
                usuarios.push(this.value);
            }
        });
        if (usuarios.length == 0) {
            alert("no has seleccionado ningun usuario");
        } else if ($("#fecha-inicio").val().length == 0 || $("#fecha-fin").val().length == 0 || ($("#fecha-inicio").val() > $("#fecha-fin").val())) {
            alert("no seleccionaste un rango de fechas valido");
        } else {
            $.ajax({
                type: "GET",
                url: "controller/generar_reporte.php",
                data: {
                    usuarios: usuarios,
                    fecha_inicio: $("#fecha-inicio").val(),
                    fecha_fin: $("#fecha-fin").val()
                },
                async: false,
                dataType: "json",
                statusCode: {
                    200: function (XHTMLHttpRequest) {
                        reportes = XHTMLHttpRequest;
                        $(".contenido").load("view/ver_reporte.html", function () {
                            rangos = reportes['rango'];
                            rango = rangos.pop();
                            while (rango) {
                                $(".tbl-head").append("<th>" + rango + "</th>");
                                rango = rangos.pop();
                            }
                            $(".tbl-head").append("<th>Horas totales</th>");
                            resultados = reportes['resultados'];
                            resultado = resultados.pop();
                            while (resultado) {
                                nombre_completo = resultado['nombre_completo'];
                                usuario = resultado['usuario'];
                                $(".tbl-bdy").append("<tr id=" + usuario + ">");
                                $(".tbl-bdy #" + usuario).append("<th scope='row'>" + nombre_completo + "</th>");
                                horas_cumplidas = resultado['horas_cumplidas'];
                                hora_cumplida = horas_cumplidas.pop();
                                while (hora_cumplida) {
                                    $(".tbl-bdy #" + usuario).append("<td>" + hora_cumplida + "</td>");
                                    hora_cumplida = horas_cumplidas.pop();
                                }
                                $(".tbl-bdy #" + usuario).append("<td>" + resultado['totales'] + "</td>");
                                resultado = resultados.pop();
                            }
                            $('#dataTable').DataTable();
                        });
                    },
                    401: function (XHTMLHttpRequest) {
                        if (XHTMLHttpRequest == false) {
                            location.href = "index.php";
                        }
                        location.href = "index.php";
                    }
                }
            });

        }

    }
    function reporte_excel() {
        $(".reporte-tbl").tableHTMLExport({
            type: 'csv',
            filename: 'reporte_asistencia.csv',
            separator: ',',
            newline: "\r\n",
            trimContent: true,
            quoteFields: true,
            htmlContent: false,
        });
    }
    function cerrar_sesion() {
        $.ajax({
            type: "GET",
            url: "controller/cerrar_sesion.php",
            statusCode: {
                200: function (texto) {
                    sessionStorage.clear();
                    alert("Sesion cerrada");
                    location.href = "index.php";
                }
            }
        });
    }
    function reporte_asistencia() {
        $(".active").removeClass("active");
        $(".reporte-asistencia").addClass("active");
        $(".breadcrumb").html("<li class='breadcrumb-item'><a href='#'>Panel</a></li><li class='breadcrumb-item active'>Generador de reportes</li>");
        $(".contenido").load("view/ver_nuevo_reporte.html", function () {
            usuarios = get_usuarios();
            usuario = usuarios.pop();
            while (usuario) {
                if (usuario['ID_TIPO'] == 3)
                    $("#id_usuario").append("<option value='" + usuario['ID_USUARIO'] + "'>" + usuario['USUARIO'] + " - " + usuario['NOMBRE'] + " " + usuario['APELLIDO'] + "</option>");
                usuario = usuarios.pop();
            }
            $('.selectpicker').selectpicker();
            $('.datepicker').datepicker({
                format: 'yyyy-mm-dd'
            });
        });
    }
    function historial_asistencia() {
        $(".active").removeClass("active");
        $(".historial-asistencia").addClass("active");
        $(".breadcrumb").html("<li class='breadcrumb-item'><a href='#'>Panel</a></li><li class='breadcrumb-item active'>Historial de asistencias</li>");
        $(".contenido").load("view/ver_historial_asistencia.html", function () {
            asistencias = get_asistencias();
            asistencia = asistencias.pop();
            while (asistencia) {
                $("#tbl-bdy").append('<tr id=tr-usr' + asistencia.ID_ASISTENCIA + "><td>" + asistencia.USUARIO + "</td><td>" + asistencia.CHECK_ENTRADA + "</td><td>" + asistencia.HORA_ENTRADA + "</td><td>" + asistencia.CHECK_SALIDA + "</td><td>" + asistencia.HORA_SALIDA + "</td><td>" + asistencia.HORAS_CUMPLIDAS + "</td><td>" + asistencia.FECHA + "</td></tr>");
                asistencia = asistencias.pop();
            }
            $('#dataTable').DataTable();
        });
    }
    function get_reg_horario() {
        horario = {
            id_usuario: $("#id_usuario").val(),
            horario: []
        };
        $.each($("#tbl-bdy tr"), function (indexInArray, valueOfElement) {
            horario_child = {
                id_dia: valueOfElement['children'][2]['children'][0].value,
                hora_entrada: valueOfElement['children'][0]['children'][0].value,
                hora_salida: valueOfElement['children'][1]['children'][0].value
            };
            if (horario_child['hora_entrada'] < horario_child['hora_salida']) {
                horario["horario"].push(horario_child);
            }
        });
        return horario;
    }

    function definir_actividad() {
        $(".breadcrumb").html("<li class='breadcrumb-item'><a href='#'>Panel</a></li><li class='breadcrumb-item active'>Periodo de actividad</li>");
        id_usuario = $(this).attr('id');
        $(".contenido").load("view/registrar_periodo_reporte.html", function () {
            $('.datepicker').datepicker({
                format: 'yyyy-mm-dd',
                language: 'es-ES',
                weekStart: 1,
                startDate: '2015-03-03'
            });
        });
    }

    function ver_actividad() {
        fecha_inicio = $("#fecha-inicio").val();
        fecha_fin = $("#fecha-fin").val();
        if (fecha_inicio != '' && fecha_fin != '' && fecha_fin > fecha_inicio) {
            $(".breadcrumb").html("<li class='breadcrumb-item'><a href='#'>Panel</a></li><li class='breadcrumb-item active'>Reporte de actividad</li>");
            $(".contenido").load("view/ver_actividad_usuario.html", function () {
                usuario = get_usuario(id_usuario);
                $.ajax({
                    type: "GET",
                    url: "controller/get_reporte.php",
                    data: {
                        id_usuario: id_usuario
                    },
                    dataType: "json",
                    async: false,
                    statusCode: {
                        200: function (XHTMLHttpRequest) {
                            graficar_actividad(XHTMLHttpRequest, "Grafica del usuario " + usuario.USUARIO + " de " + fecha_inicio + " a " + fecha_fin, fecha_inicio, fecha_fin);
                            $('.datepicker').datepicker({
                                format: 'yyyy-mm-dd',
                                language: 'es-ES',
                                weekStart: 1,
                                startDate: '2015-03-03'
                            });
                        }
                    }

                });
            });
        }else{
            alert("no has seleccionado un periodo valido");
        }
    }

    function graficar_actividad(actividades, titulo, fecha_inicio, fecha_fin) {
        var ctx = document.getElementById('grafica-actividades').getContext('2d');
        data = { datasets: [{ data: [], backgroundColor: [] }], labels: [] }
        actividades.forEach(actividad => {
            if (actividad.FECHA > fecha_inicio && actividad.FECHA < fecha_fin) {
                time = actividad.TIEMPO;
                tt = time.split(":");
                sec = tt[0] * 3600 + tt[1] * 60 + tt[2] * 1;
                data.datasets[0].data.push(sec);
                data.datasets[0].backgroundColor.push('#' + ('000000' + Math.floor(Math.random() * 16777215).toString(16)).slice(-6));
                data.labels.push(actividad.PROGRAMA);
            }
        });
        options = { title: { display: true, text: titulo } }
        var myPieChart = new Chart(ctx, {
            type: 'pie',
            data: data,
            options: options
        });
    }

    // BOTONES CONTENIDO
    $(".contenido").on("click", ".btn-reporte-excel", reporte_excel);
    $(".contenido").on("click", ".btn-generar-reporte", generar_reporte);
    $(".contenido").on("click", ".reg-horario-usr", registrar_horario);
    $(".contenido").on("click", ".btn-registrar-usuario", registrar_usuario_commit);
    $(".contenido").on("click", ".eliminar-usr", eliminar_usuario_commit);
    $(".contenido").on("click", ".ver-horario-usr", ver_horario);
    $(".contenido").on("click", ".btn-del-reg-dia", del_reg_dia);
    $(".contenido").on("click", ".btn-add-reg-dia", add_reg_dia);
    $(".contenido").on("click", ".btn-modificar-usuario-commit", modificar_usuario_commit);
    $(".contenido").on("click", ".btn-commit-horario", commit_horario);
    $(".contenido").on("click", ".definir-actividad-usr", definir_actividad);
    $(".contenido").on("click", ".ver-actividad-usr", ver_actividad);
    $(".container").on("click", ".btn-login", login);

    // BOTONES MENU
    $("#wrapper").on("click", ".modificar-usr", modificar_usuario_view);
    $("#wrapper").on("click", ".cerrar-sesion", cerrar_sesion);
    $("#wrapper").on("click", ".reporte-asistencia", reporte_asistencia);
    $("#wrapper").on("click", ".historial-asistencia", historial_asistencia);
    $("#wrapper").on("click", ".reporte-actividad", ver_usuario_actividad);
    $("#wrapper").on("click", ".modificar-usuario", ver_usuarios);
    $("#wrapper").on("click", ".registrar-horario", ver_usuario_reg_horarios);
    $("#wrapper").on("click", ".registrar-usuario", registrar_usuario);
    $("#wrapper").on("click", ".index", index);
});