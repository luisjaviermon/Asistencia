##Requerimientos POLARIS

### 1 Modulo Usuario
#### 1.1 Registrar usuario
#### 1.2 Modificar usuario
#### 1.3 Eliminar usuario
### 2 Modulo Asistencia
#### 2.1 Asignar horario a usuario
##### 2.1.1 Asignar horario de entrada
##### 2.1.2 Asignar horario de salida
#### 2.2 Registro de asistencia
##### 2.2.1 Registrar entrada
##### 2.2.2 Registrar saida
##### 2.2.3 Validar entrada
##### 2.2.4 Validar salida
### 3 Modulo de Reporte
#### 3.1 Generar reporte
##### 3.1.1 Crear listado de usuarios activos 
##### 3.1.2 Asignar periodo de tiempo del reporte
##### 3.1.3 Generar tabla de horas cumplidas en el periodo de tiempo asignado