## Requerimientos no funcionales

### Servidor Backend
#### 1 PHP
#### 1.1 Framework
##### 1.1.1 ZendFramework2
#### 1.2 Manejador de BD con ODBC
##### 1.2.1 MySQL
##### 1.2.2 PostgreSQL
#### 1.3 Generador de QR

### Cliente Frontend
#### 1 Cliente de escritorio
##### 1.1 ECMAscript compatible
###### 1.1.1 JQuery
#### 2 Cliente Movil
##### 2.1 Aplicacion android
###### 2.1.1 Lector de QR
##### 2.2 Aplicacion IOS
###### 2.2.1 Lector de QR